package org.acme.rest.client;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class ExtensionsResourceIT extends ExtensionsResourceTest {

    // Execute the same tests but in native mode.
}
